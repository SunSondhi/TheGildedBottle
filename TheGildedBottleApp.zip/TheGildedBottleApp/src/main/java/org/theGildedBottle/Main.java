package org.theGildedBottle;

public class Main {
    public static void main(String[] args) {
        new ContentManager(new MainFrame("The Gilded Bottle Application"));
    }
}