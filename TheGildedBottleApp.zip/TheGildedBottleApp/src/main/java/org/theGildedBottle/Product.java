package org.theGildedBottle;

public class Product {
}
